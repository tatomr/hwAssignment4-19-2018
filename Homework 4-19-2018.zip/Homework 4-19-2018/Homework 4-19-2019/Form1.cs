﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Homework_4_19_2019;

namespace Homework_4_19_2019
{
    public partial class Form1 : Form
    {   //SQL Connection specfies the server name, database and authentication information. 
        // Constant value cannot be changed during operation.
        const string ConnString = @"Server=PL13\MTCDBDEV;Database=AdventureWorks2012;Trusted_Connection = True;";
        SqlConnection sqlConnection = new SqlConnection(ConnString);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)

        {

            {
                //Declare and instantiate the Data Adapter with a stored procedure "dbo.spCustomerID_Name".
                //Adapter used for moving data back and forth between SQL Server.
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter("spCustomerID_Name", sqlConnection);
                //New empty Data Table is declare and instatiated for holding data retrieved using the stored procedure. 
                DataTable dtCustomerInfo = new DataTable();

                //Veriable Declared
                int CustomerID;
                string CustomerName;
                try
                {
                    //Fill method used to fill the DataTable with the data it retrieved from SQL Server.
                    sqlDataAdapter.Fill(dtCustomerInfo);

                    //The foreach loop is used to iterate through the DataRows in the "drCustomerInfo" DataTable. 
                    foreach (DataRow drCustomer in dtCustomerInfo.Rows)
                    {

                        //Referring to the items in the array, by using the correct index number.
                        //Values are in the same order as returned by the stored procedure.
                        CustomerID = int.Parse(drCustomer.ItemArray[0].ToString());
                        CustomerName = drCustomer.ItemArray[1].ToString();
                        comboBoxCustomers.Items.Add(new cboObject(CustomerID, CustomerName));
                    }
                }

                /*If an error occures while trying to retrieve the data from SQL Server
                it will be caught and message displayed.*/
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void cbCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Retrieve the selected object in the Combobox
            cboObject current = (cboObject)comboBoxCustomers.SelectedItem;
            int CustomerID = current.CustomerID;
            /*New empty Data Table is declare and instatiated for holding data retrieved from using
            "fromdbo.SalesOrderDetailsByCustomer" stored procedure.*/
            DataTable dtCustomerOrders = new DataTable();

            try
            {   // Command Calls the "dbo.SalesOrderDetailsByCustomer" stored procedure that accepts a customerID paramater and returns the sales order details
                SqlCommand sqlComm = new SqlCommand("sp_CustomerInfo", sqlConnection);
                sqlComm.CommandType = CommandType.StoredProcedure;
                //Declaring and Initializing the SQL Paramater CustomerID
                SqlParameter prmCustomerID = new SqlParameter("@CustomerID", CustomerID);
                sqlComm.Parameters.Add(prmCustomerID);

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlComm);
                //Fill method used to fill the "dtCustomerOrders" DataTable with the data it retrieved from SQL Server.
                sqlDa.Fill(dtCustomerOrders);
                //Displays the retrieved data on the DataGrid
                dataGridOrderInfo.DataSource = dtCustomerOrders;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error....");
            }
        }
        //Class designed to encapsulate the customer name and customerID to be shown to the user in combobox
        public class cboObject
        {
            int customerID;
            string customerName;

            //Class constructor that accepts two values and returns the customer name to view 
            public cboObject(int CustomerID, string CustomName)
            {
                customerID = CustomerID;
                customerName = CustomName;
            }


            public string CustomName
            {
                get { return customerName; }
                set { customerName = value; }
            }

            public int CustomerID
            {
                get { return customerID; }
                set { customerID = value; }
            }

            public override string ToString()
            {
                return this.CustomName;
            }

        }
     
        private void dataGridOrderInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Verify RowIndex value is greater than or equal to zero
            if (e.RowIndex >= 0)
            {
                //Declare and initilize the dataGridViewRow to equal to the selected cell.
                DataGridViewRow row = this.dataGridOrderInfo.Rows[e.RowIndex];
                //Display the OrderID with the value seleced in the row.Cell and convert to string.
                textBoxOrderID.Text = row.Cells[0].Value.ToString();

            }
        }

        private void dataGridOrderInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

