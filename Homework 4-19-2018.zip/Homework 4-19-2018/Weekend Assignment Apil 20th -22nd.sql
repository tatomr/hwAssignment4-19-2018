USE  [AdventureWorks2012]
GO

If (Select Count(*) 
	From master.sys.syslogins Where name = 'AdvWorks2012') > 0
BEGIN
	DROP Login AdvWorks2012;
	DROP User  AdvWorks2012;
END

/* Create login named Advworks2012 with a password.*/
CREATE LOGIN AdvWorks2012
	WITH PASSWORD = 'p@$$W0RD';
GO

/* Map login to database user. */
CREATE USER AdvWorks2012
	FOR LOGIN AdvWorks2012;

/* Add login as a member of server roles.*/
EXEC sp_addrolemember 'db_datawriter', 'AdvWorks2012';
EXEC sp_addrolemember 'db_datareader', 'AdvWorks2012';

/*Deny permissions to user on HumanResources.*/
DENY SELECT, INSERT, UPDATE, DELETE, VIEW DEFINITION ON SCHEMA :: HumanResources TO AdvWorks2012
DENY ALTER, CONTROL, CREATE SEQUENCE, TAKE OWNERSHIP, EXECUTE ON SCHEMA :: HumanResources TO AdvWorks2012
/*Deny permissions to user on Person.*/
DENY ALTER, CREATE SEQUENCE, DELETE, INSERT, UPDATE, TAKE OWNERSHIP ON SCHEMA :: Person to AdvWorks2012


-- Stored Procedure that accepts CustomerID and returns details of the sales order for customers.
GO

GO
CREATE PROC [dbo].[sp_CustomerInfo]
(@CustomerID INT)
AS
BEGIN

SELECT SalesOrderID [Order ID], OrderDate, ShipDate [Shipped Date], CONCAT(P.FirstName, ' ', P.LastName) [Full Name], 
		A.City [City Shipped], sp.Name [State/Province], o.TotalDue [Total Due]
FROM Sales.SalesOrderHeader o
LEFT JOIN Sales.SalesPerson s
ON s.BusinessEntityID = o.SalesPersonID
LEFT JOIN Person.Person p
ON P.BusinessEntityID = s.BusinessEntityID
LEFT JOIN Person.[Address] a
ON A.AddressID = o.ShipToAddressID
LEFT JOIN Person.StateProvince sp
ON sp.StateProvinceID = A.StateProvinceID
WHERE o.CustomerID = @CustomerID

END
GO
exec sp_CustomerInfo 16867

--Stored Procedure that lists the names and customerID number of all active customers.
GO
CREATE PROC spCustomerID_Name
AS
select c.CustomerID, concat(pp.LastName, ' ', pp.FirstName) [Customer Name]
from sales.Customer c
inner join
Person.Person pp
on pp.BusinessEntityID = c.CustomerID

exec spCustomerID_Name



